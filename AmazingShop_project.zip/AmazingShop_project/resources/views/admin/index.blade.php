
    @extends('adminlte::page')

@section('title', 'AmazingShop')

@section('content_header')
    <h2>AmazingShop</h2>
@stop

@section('content')
    <p>Aqui va el contenido de la pagina</p>
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop


@section('js')
    <script> console.log('Hi!'); </script>
@stop



