
    

<?php $__env->startSection('title', 'AmazingShop'); ?>

<?php $__env->startSection('content_header'); ?>
    <h2>AmazingShop</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Aqui va el contenido de la pagina</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AmazingShop_proyect\resources\views/admin/index.blade.php ENDPATH**/ ?>